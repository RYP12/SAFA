public interface Marvel {



}
