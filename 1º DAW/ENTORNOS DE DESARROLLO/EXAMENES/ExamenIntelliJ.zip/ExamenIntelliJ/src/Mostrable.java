public interface Mostrable {
    String mostrarInformacion();

}