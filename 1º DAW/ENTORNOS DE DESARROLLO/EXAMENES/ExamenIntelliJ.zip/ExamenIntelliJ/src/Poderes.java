public interface Poderes {
    double obtenerPoder();
}