package modelos;

public enum TipoHabilidad {
    DANYO, CURACION, BUFO_VIDA,
    BUFO_DEFENSA, BUFO_PODER
}