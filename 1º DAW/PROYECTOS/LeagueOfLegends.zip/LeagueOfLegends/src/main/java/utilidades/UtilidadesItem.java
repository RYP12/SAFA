package utilidades;

public class UtilidadesItem {
}
